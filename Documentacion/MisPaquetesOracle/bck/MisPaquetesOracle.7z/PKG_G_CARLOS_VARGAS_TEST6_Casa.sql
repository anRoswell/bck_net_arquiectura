CREATE OR REPLACE PACKAGE "AIRE".PKG_G_CARLOS_VARGAS_TEST6_Casa AS    
    /*
    este sp sobreescribe pgk_g_ordenes
    */
    procedure prc_registrar_orden2 (		
        e_json  in 	clob,
        s_json 	out	clob
	);

    /*
    este NO sobreescribe sp en pgk_g_ordenes
    debido a que se crea uno nuevo, la versión V2
    */
    procedure prc_registro_ordenes_masivo_final_V2 (		
        e_json      in clob,
        s_json      out clob
	);

    /*
    este sp sobreescribe pgk_g_ordenes
    */
    procedure prc_parametros_iniciales_contratistas (		        
        e_json 	in	clob,
        s_json 	out	clob
	);

END PKG_G_CARLOS_VARGAS_TEST6_Casa;
/
CREATE OR REPLACE PACKAGE BODY "AIRE".PKG_G_CARLOS_VARGAS_TEST6_Casa AS

    procedure prc_registrar_orden2 (
        e_json  		in 	clob,
        s_json 	out	clob
    ) is
        v_json_orden                json_object_t;  
        v_id_log		            aire.gnl_logs.id_log%type;
        v_respuesta                 aire.tip_respuesta := aire.tip_respuesta(mensaje => 'Registro exitoso.', nombre_up => 'pkg_g_ordenes.prc_registrar_orden2');
        v_orden      	            aire.ord_ordenes%rowtype;
        v_id_contratista            aire.ord_ordenes.id_contratista%type;
        v_estado_orden              aire.ord_estados_orden.descripcion%type;
        c_orden                     aire.gnl_clientes%rowtype;
        valor_nic                   number;
        valor_nis                   number;
        valor_id_estado_servicio    number;
        v_id_actividad              aire.gnl_actividades.id_actividad%type;  
        v_mje                       varchar2(4000) := 'Orden creada con éxito.';
        v_exist_contratista           number;      
    begin
        -- validamos el Json de la orden y armamos el rowtype
        begin
            -- parseamos el json
            v_json_orden := json_object_t(e_json);
    
            -- extraemos los datos de la orden
            c_orden.nic                     := v_json_orden.get_number('nic');
            c_orden.nis                     := v_json_orden.get_number('nis');
            valor_nic                       := c_orden.nic;
            valor_nis                       := c_orden.nis;
            
            v_orden.id_tipo_orden           := v_json_orden.get_number('id_tipo_orden');
            valor_id_estado_servicio        := v_json_orden.get_number('id_estado_servicio');
            v_orden.id_tipo_suspencion      := v_json_orden.get_number('id_tipo_suspencion');
            v_id_contratista                := v_json_orden.get_number('id_contratista');
            
            --se valida que exista el contratista y que sea de SCR.
            if v_id_contratista > 0 then
                select 
                     count(*)
                        into v_exist_contratista
                from aire.v_ctn_contratistas  
                where id_contratista in (
                        select id_contratista
                            from aire.v_ctn_contratos 
                            where UPPER(prefijo_actividad) = 'G_SCR'
                            and UPPER(ind_activo) = 'S'
                ) and id_contratista = v_id_contratista;
                
                -- Retornar error
                if v_exist_contratista = 0 then
                    v_id_log := aire.pkg_p_generales.fnc_registrar_log (v_respuesta.nombre_up, aire.pkg_p_generales.v_tipo_mensaje_error, 'Error el contratista no existe: ');
                    apex_json.initialize_clob_output( p_preserve => false );
                    apex_json.open_object();
                    apex_json.write('codigo', 1);
                    apex_json.write('mensaje', 'Error #'||v_id_log||' el contratista no existe por cuanto no se crea ninguna orden');
                    apex_json.close_object();
                    s_json := apex_json.get_clob_output;
                    apex_json.free_output;
                    return;
                end if;
            end if;
            
            select 
                aire.sec__ord_ordenes_cargue_temporal__numero_orden.NEXTVAL * -1 
                    into v_orden.numero_orden 
            from dual;
            
            select id_actividad 
                    into v_id_actividad 
            from aire.gnl_actividades where prefijo = 'G_SCR' and ind_activo = 'S';
            
            /*
            24-01-2024
            Se obtiene el valor del estado asignar 
            12-03-2024
            ahora se añade el id contratista, si viene en el json entonces 
            se utiliza en estado: Asignada a Contratista
            */
            SELECT
                id_estado_orden,descripcion 
                    into v_orden.id_estado_orden, v_estado_orden
            FROM aire.ord_estados_orden 
            where   codigo_estado = case when v_id_contratista <= 0 then 'SPEN' else 'SASI' end
            and     id_actividad  = v_id_actividad;
            
            
            select 
                 id_cliente 
                ,id_territorial
                ,id_zona
                ,direccion
                into 
                     v_orden.id_cliente
                    ,v_orden.id_territorial
                    ,v_orden.id_zona
                    ,v_orden.direcion
            from aire.gnl_clientes
            where nic = valor_nic;
            
            
            --Se realiza insert a tabla aire.ord_ordenes
            insert into aire.ord_ordenes(
                id_tipo_orden
                ,id_cliente
                ,id_estado_orden
                ,numero_orden
                ,id_actividad
                ,id_tipo_suspencion
                ,id_territorial
                ,id_zona
                ,direcion
                ,origen
                ,id_contratista
            )
            values(
                 v_orden.id_tipo_orden
                ,v_orden.id_cliente
                ,v_orden.id_estado_orden
                ,v_orden.numero_orden
                ,v_id_actividad
                ,v_orden.id_tipo_suspencion
                ,v_orden.id_territorial
                ,v_orden.id_zona
                ,v_orden.direcion
                ,'OP360'
                ,case when v_id_contratista > 0 then v_id_contratista else null end
            );
            commit;
            
            select 
                id_orden 
                into v_orden.id_orden 
            from aire.ord_ordenes 
            where numero_orden = v_orden.numero_orden;
        exception
            when others then 

                v_id_log := aire.pkg_p_generales.fnc_registrar_log (v_respuesta.nombre_up, aire.pkg_p_generales.v_tipo_mensaje_error, 'Error al procesar el json de la orden: '|| sqlerrm);
                apex_json.initialize_clob_output( p_preserve => false );
                apex_json.open_object();
                apex_json.write('codigo', 1);
                apex_json.write('mensaje', 'Error #'||v_id_log||' al registrar orden'|| sqlerrm);
                apex_json.close_object();
                s_json := apex_json.get_clob_output;
                apex_json.free_output;
                commit;
                return;
        end;
        
        if v_id_contratista > 0 then
                v_mje := 'Registro creado correctamente con el id_orden: ' || v_orden.id_orden || ', Se asigno al contratista: ' || v_id_contratista || ', y la orden quedo en estado: ' || v_estado_orden;
            else
                v_mje := 'Registro creado correctamente con el id_orden: ' || v_orden.id_orden || ', no se asigno a ningun contratista! , y la orden quedo en estado: ' || v_estado_orden;
        end if;

        apex_json.initialize_clob_output( p_preserve => false );
        apex_json.open_object();
        apex_json.write('codigo', v_orden.id_orden);
        apex_json.write('mensaje', v_mje);        
        apex_json.open_object('datos');
        apex_json.write('id_orden',v_orden.id_orden);
        apex_json.close_object();
        apex_json.close_object();
        s_json := apex_json.get_clob_output;
        apex_json.free_output;

    exception
        when others then
            v_id_log := aire.pkg_p_generales.fnc_registrar_log (v_respuesta.nombre_up, aire.pkg_p_generales.v_tipo_mensaje_error, 'Error al registrar orden: '|| sqlerrm);
            apex_json.initialize_clob_output( p_preserve => false );
            apex_json.open_object();
            apex_json.write('codigo', 1);
            apex_json.write('mensaje', 'Error #'||v_id_log||' al registrar orden' || sqlerrm);
            apex_json.close_object();
            s_json := apex_json.get_clob_output;
            apex_json.free_output;
            commit;
    end prc_registrar_orden2;

    procedure prc_registro_ordenes_masivo_final_V2 (
        e_json  		in 	clob,
        s_json 	        out	clob
    ) is
        v_json_orden                json_object_t;  
        v_id_log		            aire.gnl_logs.id_log%type;
        v_respuesta                 aire.tip_respuesta := aire.tip_respuesta(mensaje => 'Registro exitoso.', nombre_up => 'pkg_g_ordenes.prc_registro_ordenes_masivo_final');
        
        v_id_soporte                NUMBER;
        v_usuario_registra          VARCHAR2(50 BYTE);                
        v_nombre_archivo            VARCHAR2(100 BYTE);
        
        --v_numero_orden              NUMBER;
        v_id_archivo                NUMBER;
        v_id_actividad              NUMBER;
        v_id_archivo_instancia      NUMBER;
        v_fechainicio               timestamp;
        v_id_estado_orden           NUMBER;
    begin
        ----e_json := '{"id_soporte":1720,"usuario_registra",362,"nombre_archivo":"minombre.xlsx"}';
        -- validamos el Json de la orden y armamos el rowtype
        begin
            -- parseamos el json
            v_json_orden := json_object_t(e_json);
    
            -- extraemos los datos de la orden            
            v_id_soporte               := v_json_orden.get_number('id_soporte');
            v_usuario_registra         := v_json_orden.get_string('usuario_registra');            
            v_nombre_archivo           := v_json_orden.get_string('nombre_archivo');
            
            --actualizar tabla temporal  aire.ord_ordenes_cargue_temporal
            UPDATE aire.ord_ordenes_cargue_temporal
            SET Numero_Orden = aire.sec__ord_ordenes_cargue_temporal__numero_orden.NEXTVAL * -1
            where Numero_Orden is null and id_soporte = v_id_soporte and usuario_registra = v_usuario_registra;


            SELECT
                 id_archivo into v_id_archivo
            FROM aire.gnl_archivos x
            WHERE x.codigo = 'OTAC';
           
            SELECT
                id_actividad into v_id_actividad
            FROM aire.gnl_actividades x
            WHERE x.prefijo = 'G_SCR' and x.ind_activo = 'S';    
            
            SELECT    
                min(fecha_registra) into v_fechainicio
            FROM aire.ord_ordenes_cargue_temporal
            where id_soporte = v_id_soporte;
        exception
            when others then 
                v_id_log := aire.pkg_p_generales.fnc_registrar_log (v_respuesta.nombre_up, aire.pkg_p_generales.v_tipo_mensaje_error, 'Error al procesar el json de la orden: '|| sqlerrm);
                apex_json.initialize_clob_output( p_preserve => false );
                apex_json.open_object();
                apex_json.write('codigo', 400);
                apex_json.write('mensaje', 'Error #'||v_id_log||' al registrar las ordenes masivas'|| sqlerrm);
                apex_json.close_object();
                s_json := apex_json.get_clob_output;
                apex_json.free_output;
                return;
        end;
        
        --ACA EL CODIGO PRINCIPAL
            MERGE
            INTO    aire.ord_ordenes_cargue_temporal trg
            USING   (
                    SELECT    
                         x.Numero_Orden
                         
                        ,x.nic
                        --//--validar si el nic es numerico
                        ,case when REGEXP_LIKE(x.nic, '^[[:digit:]]+$') then 0 else 1 end                                       vnic
                        ,(select nvl(sum(0),1) from aire.gnl_clientes where nic = x.nic)                                        enic
                        
                        ,x.codigo_tipo_orden
                        --//--validar si el tipo orden es texto
                        ,case when REGEXP_LIKE(x.codigo_tipo_orden, '^[[:digit:]]+$') then 1 else 0 end                         vtor
                        ,(select nvl(sum(0),1) from aire.ord_tipos_orden where codigo_tipo_orden = x.codigo_tipo_orden)         etor
                        
                        ,x.codigo_tipo_suspencion
                        --//--validar si el tipo suspensión es texto
                        ,case when REGEXP_LIKE(x.codigo_tipo_suspencion, '^[[:digit:]]+$') then 1 else 0 end                    vtsu
                        ,(select nvl(sum(0),1) from aire.scr_tipos_suspencion where codigo = x.codigo_tipo_suspencion)          etsu
                        
                        ,x.codigo_estado_servicio
                        --//--validar si el tipo suspensión es texto
                        ,case when REGEXP_LIKE(x.codigo_estado_servicio, '^[[:digit:]]+$') then 1 else 0 end                    vtes
                        ,(select nvl(sum(0),1) from aire.gnl_estados_servicio where codigo = x.codigo_estado_servicio)          etes
                    FROM aire.ord_ordenes_cargue_temporal x
                    WHERE x.id_soporte = v_id_soporte and x.usuario_registra = v_usuario_registra
                    --WHERE x.id_soporte = 1720 and x.usuario_registra = '362'
                    order by 1
                    ) src
            ON      (trg.Numero_Orden = src.Numero_Orden)
            WHEN MATCHED THEN UPDATE
                SET 
                    trg.con_errores = case when ((vnic + vtor) + (enic + etor) + (vtsu + etsu) + (vtes + etes)) = 0 then 0 else 1 end,
                    trg.desc_validacion = 
                                case when ((vnic + vtor) + (enic + etor) + (vtsu + etsu) + (vtes + etes)) <= 0 then 'Validación Exitosa' end ||
                                case when (vnic + vtor + vtsu + vtes) > 0 then '-Tipo de dato incorrecto para: ' end    || case when src.vnic = 1 then '*-nic' end
                                                                                                                        || case when src.vtor = 1 then ' *-tipo_orden' end 
                                                                                                                        || case when src.vtsu = 1 then ' *-tipo_suspencion' end 
                                                                                                                        || case when src.vtes = 1 then ' *-estado_servicio' end 
                                || case when (enic + etor + etsu + etes) > 0 then ' -No se encontraron los registros para: ' end    || case when src.enic = 1 then '*-nic' end
                                                                                                                                    || case when src.etor = 1 then ' *-tipo_orden' end 
                                                                                                                                    || case when src.etsu = 1 then ' *-tipo_suspencion' end
                                                                                                                                    || case when src.etes = 1 then ' *-estado_servicio' end;
        
        /*
        24-01-2024
        Se obtiene el valor del estado asignar 
        */
        SELECT
            id_estado_orden into v_id_estado_orden
        FROM aire.ord_estados_orden 
        where   codigo_estado = 'SPEN' 
        and     id_actividad IN (select id_actividad from aire.gnl_actividades where prefijo = 'G_SCR' and ind_activo = 'S');
        
        --Crear registros de ordenes masivamente.       
            insert into aire.ord_ordenes
            (
                id_tipo_orden
                ,id_cliente                
                ,id_estado_orden
                ,numero_orden
                ,id_actividad
                ,id_tipo_suspencion
                ,origen
                ,id_territorial
                ,id_zona
                ,direcion                
            )
            select 
                 --x.id_tipo_orden
                 t.id_tipo_orden
                ,c.id_cliente
                ,v_id_estado_orden id_estado_orden
                ,x.numero_orden numero_orden                
                ,v_id_actividad
                --,x.id_tipo_suspencion            
                ,s.id_tipo_suspencion
                ,'OP360'
                ,c.id_territorial
                ,c.id_zona
                ,c.direccion
            from aire.ord_ordenes_cargue_temporal x
            left join aire.gnl_clientes c on c.nic = x.nic
            left join aire.ord_tipos_orden t on t.codigo_tipo_orden = x.codigo_tipo_orden
            left join aire.scr_tipos_suspencion s on s.codigo = x.codigo_tipo_suspencion
            WHERE x.id_soporte = v_id_soporte and x.usuario_registra = v_usuario_registra and x.con_errores = 0;
            
            insert into aire.ord_ordenes_soporte
            (id_orden,id_soporte)
            select
                 x.id_orden
                , v_id_soporte id_soporte
            from aire.ord_ordenes x
            inner join aire.ord_ordenes_cargue_temporal tmp 
                                on  tmp.numero_orden = x.numero_orden
                                and tmp.id_soporte = v_id_soporte 
                                and tmp.usuario_registra = v_usuario_registra 
                                and tmp.con_errores = 0;
            
        --Alimentar el log.
        --tabla principal
            INSERT INTO aire.gnl_archivos_instancia
            (
                --id_archivo_instancia,
                id_archivo,
                nombre_archivo,
                numero_registros_archivo,
                numero_registros_procesados,
                numero_errores,
                fecha_inicio_cargue,
                fecha_fin_cargue,
                duracion,
                id_usuario_registro,
                fecha_registro,
                id_estado_intancia,
                observaciones,
                id_soporte    
            )
            SELECT
                 --x.id_archivo_instancia
                 v_id_archivo id_archivo
                ,v_nombre_archivo nombre_archivo
                ,SUM(1) numero_registros_archivo
                ,SUM(case when con_errores = 0 then 1 else 0 end) numero_registros_procesados
                ,SUM(con_errores) numero_errores
                ,v_fechainicio fecha_inicio_cargue
                ,localtimestamp fecha_fin_cargue
                ,'0' duracion
                ,v_usuario_registra id_usuario_registro
                ,localtimestamp fecha_registro
                ,163 id_estado_intancia --Finalizado
                ,'se cargaron ' || SUM(case when con_errores = 0 then 1 else 0 end) || ' ordenes.' observaciones
                ,v_id_soporte id_soporte
            FROM aire.ord_ordenes_cargue_temporal x
            where id_soporte = v_id_soporte and usuario_registra = v_usuario_registra
            group by id_soporte,usuario_registra;
        
        --se obtiene el id de la tabla principal
            select id_archivo_instancia into v_id_archivo_instancia
            from aire.gnl_archivos_instancia 
            where id_soporte = v_id_soporte;
        
        --se alimenta la tabla detalle
            INSERT INTO aire.gnl_archivos_instancia_detalle
            (
            --id_archivo_instancia_detalle
             id_archivo_instancia
            ,numero_fila
            ,estado
            ,observaciones
            )
            SELECT
                 --id_archivo_instancia_detalle
                v_id_archivo_instancia id_archivo_instancia
                ,rownum numero_fila
                ,case when x.con_errores = 1 then 'ERROR' else 'OK' end estado
                ,x.desc_validacion observaciones
            FROM aire.ord_ordenes_cargue_temporal x    
            where id_soporte = v_id_soporte and usuario_registra = v_usuario_registra;
            
        --se actualiza la fecha final
        
        UPDATE aire.gnl_archivos_instancia
        SET fecha_fin_cargue = localtimestamp, duracion = localtimestamp - fecha_inicio_cargue
        WHERE id_soporte = v_id_soporte and id_usuario_registro = v_usuario_registra and id_archivo_instancia = v_id_archivo_instancia;
        
        --se eliminan los registros de la tabla temporal aire.ord_ordenes_cargue_temporal
            DELETE aire.ord_ordenes_cargue_temporal            
            WHERE id_soporte = v_id_soporte and usuario_registra = v_usuario_registra;
        
        commit;
        
        --------------------------------------------------------------------------------------
        apex_json.initialize_clob_output( p_preserve => false );
        apex_json.open_object();
        apex_json.write('codigo', 200);
        apex_json.write('mensaje', 'Ordenes masivas creadas con éxito.');		
        apex_json.open_object('datos');
            apex_json.open_array('ordenes');
                for c_datos in (
                    select id_orden 
                    from aire.ord_ordenes_soporte 
                    where id_soporte = v_id_soporte
                ) loop
                apex_json.open_object();
                    apex_json.write('id_ordenes',c_datos.id_orden);
                apex_json.close_object();
                end loop;
            apex_json.close_array();		
        apex_json.close_object();
        apex_json.close_object();
        s_json := apex_json.get_clob_output;
        apex_json.free_output;
        
    exception
        when others then
            v_id_log := aire.pkg_p_generales.fnc_registrar_log (v_respuesta.nombre_up, aire.pkg_g_seguridad.v_tipo_mensaje_error, 'Error al registrar orden: '|| sqlerrm);
            apex_json.initialize_clob_output( p_preserve => false );
            apex_json.open_object();
            apex_json.write('codigo', 400);
            apex_json.write('mensaje', 'Error #'||v_id_log||' al registrar las ordenas masivas' || sqlerrm);
            apex_json.close_object();
            s_json := apex_json.get_clob_output;
            apex_json.free_output;
    end prc_registro_ordenes_masivo_final_V2;


    procedure prc_parametros_iniciales_contratistas (		
        e_json 	in	clob,
        s_json 	out	clob
    ) is
        --v_json              clob;
        v_json_objeto       json_object_t; 
        v_id_actividad      NUMBER(3,0);
        v_id_contratista    VARCHAR2(100 BYTE);
        v_id_persona    VARCHAR2(50 BYTE);
        v_id_log		aire.gnl_logs.id_log%type;
        v_respuesta		aire.tip_respuesta :=   aire.tip_respuesta( mensaje     => 'Carga realizada con exito.', nombre_up   => 'pkg_g_ordenes.prc_parametros_iniciales_contratistas');
    BEGIN
        -- consultamos el id de la actividad de SCR
        begin
            select id_actividad
              into v_id_actividad
              from aire.gnl_actividades
             where prefijo = 'G_SCR' and ind_activo = 'S';
        exception          
            when others then
                v_id_log := aire.pkg_p_generales.fnc_registrar_log (v_respuesta.nombre_up, aire.pkg_g_seguridad.v_tipo_mensaje_seguimiento, 'Error al consultar la actividad de SCR: '||sqlerrm);
                --sb_escribir_respuesta(1, 'Error N '||v_id_log||' al registrar cuestionario: no se encuentra parametrizda la actividad SCR');
                apex_json.free_output; 
                apex_json.open_object();
                apex_json.write('codigo', 1);
                apex_json.write('mensaje', 'Error N '||v_id_log ||' al registrar cuestionario: no se encuentra parametrizda la actividad SCR');            
                apex_json.close_object();
                --v_json := apex_json.get_clob_output;
                s_json := apex_json.get_clob_output;
                apex_json.free_output;
        end;
        
        --LOG
        v_id_log := aire.pkg_p_generales.fnc_registrar_log (v_respuesta.nombre_up, aire.pkg_g_seguridad.v_tipo_mensaje_seguimiento, 'Entro a crear JSON');
        
        -- Deserializar JSON
        apex_json.free_output; 
        apex_json.initialize_clob_output( p_preserve => false );
        
        v_json_objeto           := json_object_t(e_json);   
        -- Ahora llega el id persona del analista del contratista y se halla a partir del mismo el contratista. 
        v_id_persona        := v_json_objeto.get_string('id_persona');        
        apex_json.free_output;    
        
        -- consultamos el id de la actividad de SCR
        /*SELECT
            nvl(id_contratista,'-1') into v_id_contratista
        FROM aire.v_ctn_contratistas
        where identificacion = v_identificacion;*/

        select          
            nvl(a.id_contratista,'-1') into v_id_contratista
        from aire.ctn_contratistas_persona		a 
        where a.id_contratista in (
            select 
                id_contratista
            from aire.v_ctn_contratos
            where UPPER(prefijo_actividad) = 'G_SCR'
            and UPPER(ind_activo) = 'S'
        )
        and a.id_persona = v_id_persona and a.codigo_rol = 'ANALISTA';
        
        
        apex_json.open_object();        
            apex_json.write('codigo', 0);
            apex_json.write('mensaje', 'Carga exitosa');
            apex_json.open_object('datos');
            -- Tipos de orden                
                    for c_datos in (
                        SELECT distinct
                             cp.id_contratista
                            ,cp.identificacion_contratista
                            ,cp.nombre_contratista
                        FROM aire.v_ctn_contratistas_persona cp
                        where cp.ind_activo = 'S' and cp.id_contratista = v_id_contratista
                        order by cp.id_contratista
                    ) loop                       
                        apex_json.write('id_contratista', c_datos.id_contratista);
                        apex_json.write('identificacion_contratista', c_datos.identificacion_contratista);
                        apex_json.write('nombre_contratista',c_datos.nombre_contratista);
                        apex_json.open_array('Brigadas');
                            -- Brigadas
                             for x_datos in (
                                select          
                                    a.id_contratista_persona
                                    ,a.identificacion_contratista_persona
                                    ,a.nombre_contratista_persona
                                from aire.v_ctn_contratistas_persona		a 
                                where a.id_contratista in (
                                    select 
                                        id_contratista
                                    from aire.v_ctn_contratos
                                    where LOWER(prefijo_actividad) = 'g_scr'
                                    and LOWER(ind_activo) = 's'
                                )
                                and LOWER(a.ind_activo) = 's' and a.id_contratista = c_datos.id_contratista and LOWER(a.codigo_rol) = 'tecnico'
                                order by a.id_contratista_persona
                            ) loop
                            apex_json.open_object();
                                apex_json.write('id_contratista_persona', x_datos.id_contratista_persona);
                                apex_json.write('identificacion_contratista_persona', x_datos.identificacion_contratista_persona);
                                apex_json.write('nombre_contratista_persona', x_datos.nombre_contratista_persona);
                            apex_json.close_object();
                            end loop;                                
                        apex_json.close_array(); 

                        -- gnl_zonas
                        apex_json.open_array('Zonas');
                            for c_zonas in (
                                select z.id_zona
                                    , z.id_territorial
                                    , z.codigo
                                    , z.nombre
                                from aire.gnl_zonas z 
                                where z.ind_activo = 'S'
                                    and z.id_zona in (
                                        select id_zona 
                                        from aire.ctn_contratos_zona 
                                        where id_contrato in (
                                                    select id_contrato 
                                                      from aire.v_ctn_contratos 
                                                     where prefijo_actividad = 'G_SCR' 
                                                       and id_contratista    = c_datos.id_contratista
                                                    )
                                    )
                            ) loop
                                apex_json.open_object();
                                apex_json.write('id_zona', c_zonas.id_zona);
                                apex_json.write('id_territorial', c_zonas.id_territorial);
                                apex_json.write('codigo', c_zonas.codigo);
                                apex_json.write('nombre', c_zonas.nombre);
                                apex_json.close_object();
                            end loop;
                        apex_json.close_array();
                    end loop;


                    -- tipos_suspencion
                    apex_json.open_array('tipos_suspencion');
                        for c_datos in (
                            SELECT    
                                codigo
                                ,descripcion
                            FROM aire.scr_tipos_suspencion x
                            WHERE       x.ind_activo = 'S' 
                                    and x.id_actividad = v_id_actividad
                        ) loop
                            apex_json.open_object();
                            apex_json.write('codigo', c_datos.codigo);
                            apex_json.write('descripcion', c_datos.descripcion);
                            apex_json.close_object();
                        end loop;
                    apex_json.close_array();
                    
                    -- Estados orden
                    apex_json.open_array('estados_orden');
                        for c_datos2 in (
                            select id_estado_orden
                                , codigo_estado
                                , descripcion
                            from aire.ord_estados_orden
                            where id_actividad     = v_id_actividad
                            and ind_activo = 'S' and codigo_estado not in ('CERR')
                        ) loop
                            apex_json.open_object();
                            apex_json.write('id_estado_orden', c_datos2.id_estado_orden);
                            apex_json.write('codigo_estado',c_datos2.codigo_estado);
                            apex_json.write('descripcion',c_datos2.descripcion);
                            apex_json.close_object();
                        end loop;
                    apex_json.close_array();

                    -- agrupamiento asignadas y no asignadas 
                    apex_json.open_array('grafica_asignacion');
                        for c_datos in (
                            select
                                case 
                                    when a.id_contratista_persona is null then 'no asignadas'
                                    else 'asignadas'
                                end as asignacion,
                                count(*) as noregistros
                            from aire.ord_ordenes a
                            where a.id_contratista = v_id_contratista                            
                            group by
                                case 
                                    when a.id_contratista_persona is null then 'no asignadas'
                                    else 'asignadas'
                                end                    
                        ) loop
                        apex_json.open_object();
                            apex_json.write('asignacion', c_datos.asignacion);
                            apex_json.write('noregistros', c_datos.noregistros);
                        apex_json.close_object();
                        end loop;
                    apex_json.close_array();
            apex_json.close_object();            
        apex_json.close_object();
        
        ---v_json := apex_json.get_clob_output;
        s_json := apex_json.get_clob_output;
        apex_json.free_output;         
        --s_json := v_json;
        v_id_log := aire.pkg_p_generales.fnc_registrar_log (v_respuesta.nombre_up, aire.pkg_g_seguridad.v_tipo_mensaje_seguimiento, 'Carga exitosa');        
        --dbms_output.put_line(s_json);
    exception
        when others then
            v_id_log := aire.pkg_p_generales.fnc_registrar_log (v_respuesta.nombre_up, aire.pkg_g_seguridad.v_tipo_mensaje_error, 'Error al crear el json: '|| sqlerrm);
            apex_json.free_output; 
            apex_json.open_object();
            apex_json.write('codigo', 50000);
            apex_json.write('mensaje', 'Error N '||v_id_log ||' al crear los parametros iniciales, '|| sqlerrm);            
            apex_json.close_object();
            --v_json := apex_json.get_clob_output;
            s_json := apex_json.get_clob_output;
            apex_json.free_output;
            --s_json := v_json;
    END prc_parametros_iniciales_contratistas;

END PKG_G_CARLOS_VARGAS_TEST6_Casa;