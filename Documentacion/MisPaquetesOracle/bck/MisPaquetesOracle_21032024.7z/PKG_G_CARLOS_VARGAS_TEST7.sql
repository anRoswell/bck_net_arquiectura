CREATE OR REPLACE package "AIRE".pkg_g_carlos_vargas_test7 as 

    -- este sp sobreescribe pgk_g_ordenes
    procedure prc_desasignar_ordenes_masivo_tecnico(
        e_json  in 	clob,
        s_json  out	clob
    );
end pkg_g_carlos_vargas_test7;
/
CREATE OR REPLACE package body "AIRE".pkg_g_carlos_vargas_test7 as


    procedure prc_desasignar_ordenes_masivo_tecnico(
        e_json  in 	clob,
        s_json  out	clob
    ) is
        v_respuesta                 				aire.tip_respuesta := aire.tip_respuesta(mensaje => 'Registro exitoso.', nombre_up => 'pkg_g_ordenes.prc_desasignar_ordenes_masivo_tecnico');
        v_id_soporte                				aire.gnl_soportes.id_soporte%type;
        v_id_usuario_registra       				aire.sgd_usuarios.id_usuario%type;
        v_nombre_archivo            				varchar2(250);
        v_id_archivo                				number;
        v_id_archivo_instancia      				number;
        v_fecha_inicio              				timestamp;
        v_id_orden          						aire.ord_ordenes.id_orden%type;
        v_id_estado_orden_asignada_tecnico          aire.ord_ordenes.id_estado_orden%type;
        v_id_estado_orden_asignada_contratista      aire.ord_ordenes.id_estado_orden%type;
		v_id_estado_orden							aire.ord_ordenes.id_estado_orden%type;
        v_id_contratista_persona					aire.ctn_contratistas_persona.id_contratista_persona%type;
		v_id_contratista_tecnico                    aire.ctn_contratistas.id_contratista%type;
        v_id_contratista_analista                   aire.ctn_contratistas.id_contratista%type;
		v_nic										aire.gnl_clientes.nic%type;
		v_ind_activo								varchar2(1);
        v_json_array_notificacion                   json_array_t  := json_array_t();
        v_notificacion                              json_object_t := json_object_t();
        v_id_dispositivo                            aire.sgd_usuarios.id_dispositivo%type;
        v_contador_exito                            number := 0;
        v_contador_error                            number := 0;
        v_ind_area_central                          varchar2(1);
        type 										t_temp is table of aire.ord_ordenes_temporal_desasignacion_tecnico%rowtype;
        v_temp 										t_temp;
        v_id_log		                            aire.gnl_logs.id_log%type;
        
        procedure sb_escribir_respuesta(codigo in varchar2, mensaje in varchar2, id_archivo_instancia in number default null)
        is begin
            apex_json.free_output; 
            apex_json.initialize_clob_output( p_preserve => false );
            apex_json.open_object();
            apex_json.write('codigo', codigo);
            apex_json.write('mensaje',mensaje);
            apex_json.close_object();
            s_json := apex_json.get_clob_output;
            apex_json.free_output;
        end;

        procedure sb_actualizar_temp (numero_orden_temp in varchar2, codigo in varchar2, mensaje in varchar2)
        is begin
            if codigo = '0' then
                v_contador_exito := v_contador_exito + 1;
            else
                v_contador_error := v_contador_error + 1;
            end if;

            update aire.ord_ordenes_temporal_desasignacion_tecnico
              set con_errores       = codigo 
                , desc_validacion   = mensaje
             where id_soporte       = v_id_soporte 
               and usuario_registra = v_id_usuario_registra
               and numero_orden     = numero_orden_temp;
        end;
    begin
        -- validamos el json de entrada
        if e_json is not json then
            sb_escribir_respuesta(1, 'JSON invalido');
            return;
        end if;
        
        v_id_log := aire.pkg_p_generales.fnc_registrar_log ('prc_desasignar_ordenes_masivo_tecnico', 'ERROR', 'Entrando  e_json = '||e_json);
        
        -- sacamos la informacion del JSON
        v_id_soporte            := json_value(e_json, '$.id_soporte');
        v_id_usuario_registra   := json_value(e_json, '$.usuario_registra');
        v_nombre_archivo        := json_value(e_json, '$.nombre_archivo');
        v_ind_area_central      := json_value(e_json, '$.ind_areacentral');

        if v_ind_area_central is null then
            sb_escribir_respuesta(1, 'Se debe derinir el rol de la persona que realiza el cargue');
            return;
        end if;
        -- consultamos el estado cerrada
        begin
            select id_estado_orden 
              into v_id_estado_orden_asignada_tecnico
              from aire.ord_estados_orden 
             where codigo_estado = 'SEAS';
        exception
            when others then
                sb_escribir_respuesta(1, 'Error al consultar el estado de la orden: Asignada tecnico - ' || sqlerrm);
                return;
        end;

        -- consultamos el estado legalizacion fallida
        begin
            select id_estado_orden
              into v_id_estado_orden_asignada_contratista
              from aire.ord_estados_orden
             where codigo_estado = 'SASI';
        exception
            when others then
                sb_escribir_respuesta(1, 'Error al consultar el estado de la orden: Asignada contratista - ' || sqlerrm);
                return;
        end;

        -- consultamos el archivo o el cargue
        begin
            select id_archivo
              into v_id_archivo
              from aire.gnl_archivos 
             where codigo = 'MDSG';
        exception 
            when others then
                sb_escribir_respuesta(1, 'Error al consultar el cargue: MDSG');
                return;
        end;

        -- consultamos cuando inicio el cargue
        select min(fecha_registra)
          into v_fecha_inicio
          from aire.ord_ordenes_temporal_desasignacion_tecnico
         where id_soporte       =  v_id_soporte
           and usuario_registra = v_id_usuario_registra;

        -- consultamos el contratista del analista que hace el cargue
        if v_ind_area_central = 'N' then
            begin
                select id_contratista
                  into v_id_contratista_analista
                  from aire.ctn_contratistas_persona a
                 where a.id_persona = (select id_persona from aire.sgd_usuarios where id_usuario = v_id_usuario_registra)
                   and a.codigo_rol = 'ANALISTA';
            exception
                when no_data_found then
                    sb_escribir_respuesta(1, 'No se pudo consultar el contratista asociado al analista');
                    return;
                when others then
                    sb_escribir_respuesta(1, 'Error al  consultar el contratista asociado al analista: '|| sqlerrm);
                    return;
            end;
        end if;

        select *
          bulk collect into v_temp
          from aire.ord_ordenes_temporal_desasignacion_tecnico
         where id_soporte       = v_id_soporte 
           and usuario_registra = v_id_usuario_registra; 

        if sql%rowcount = 0 then
            sb_escribir_respuesta(1, 'No se encontraron registros para procesar');
            return;
        end if;

        -- recorremos los registros
        for i in 1..v_temp.count loop
            
            if trim(v_temp(i).numero_orden) is null then
                -- actualizar registro con errores
                sb_actualizar_temp(v_temp(i).numero_orden, '1', 'El numero de la orden es requerido');
                continue;
            elsif trim(v_temp(i).nic) is null then
                -- actualizar registro con errores
                sb_actualizar_temp(v_temp(i).numero_orden, '1', 'El nic es requerido');
                continue;
            end if;
            
            
            -- consultamos la orden
            begin
                select a.id_orden
				     , a.id_estado_orden
					 , b.nic
					 , a.id_contratista_persona
                     , a.id_contratista
                  into v_id_orden
				     , v_id_estado_orden
					 , v_nic
					 , v_id_contratista_persona
                     , v_id_contratista_tecnico
                  from aire.ord_ordenes  a
				  join aire.gnl_clientes b on a.id_cliente = b.id_cliente
                 where a.numero_orden    = to_number(v_temp(i).numero_orden);
dbms_output.put_line('v_id_estado_orden: '||v_id_estado_orden||' v_id_estado_orden_asignada_tecnico: '|| v_id_estado_orden_asignada_tecnico);
				-- validamos el estado de la orden
				if v_id_estado_orden <> v_id_estado_orden_asignada_tecnico then
                    -- actualizar registro con errores
                    sb_actualizar_temp(v_temp(i).numero_orden, '1', 'La orden '||v_temp(i).numero_orden||' no tiene un estado valido');
                    continue;				
				end if;

				-- validamos el nic
				if v_nic <> trim(v_temp(i).nic) then
                    -- actualizar registro con errores
                    sb_actualizar_temp(v_temp(i).numero_orden, '1', 'La orden '||v_temp(i).numero_orden||' no se encuentra asociada al nic '||v_temp(i).nic);
                    continue;				
				end if;

                -- si es contratista validamos que quien hace el cargue tenga asociado el mismo tecnico que el contratista
                if v_id_contratista_analista <> v_id_contratista_tecnico and v_ind_area_central = 'N' then
                    -- actualizar registro con errores
                    sb_actualizar_temp(v_temp(i).numero_orden, '1', 'El tecnico que tiene asociado la orden  '||v_temp(i).numero_orden||' no se encuentra asociado al contratista que tiene asignado el analista');
                    continue;
                end if;

            exception
                when no_data_found then
                    -- actualizar registro con errores
                    sb_actualizar_temp(v_temp(i).numero_orden, '1', 'La orden '||v_temp(i).numero_orden||' no existe');
                    continue;
                when others then
                    -- actualizar registro con errores
                    sb_actualizar_temp(v_temp(i).numero_orden, '1', 'Error al consultar la orden '||v_temp(i).numero_orden||': '|| sqlerrm);
                    continue;
			end;
          
			-- desasignamos la orden al tecnico y marcamos la orden como asignada contratista
			begin
				update aire.ord_ordenes
				   set id_estado_orden        = v_id_estado_orden_asignada_contratista
				   	 , id_contratista_persona = null
				 where id_orden = v_id_orden;
			exception
				when others then
                    -- actualizar registro con errores
                    sb_actualizar_temp(v_temp(i).numero_orden, '1', 'Error al desasignar la orden '||v_temp(i).numero_orden||' a tecnico '|| sqlerrm);
                    continue;					
			end;
			
			begin
				-- notificamos al usuario
				select id_dispositivo
			      into v_id_dispositivo
				  from aire.sgd_usuarios
				 where id_persona = (
										select id_persona
				  						  from aire.ctn_contratistas_persona
										 where id_contratista_persona = v_id_contratista_persona
					   );

				v_notificacion := json_object_t();
				v_notificacion.put('id_dispositivo', v_id_dispositivo);
				v_notificacion.put('ind_android', true);
				v_notificacion.put('titulo', 'Desasignación ordenes SCR');
				v_notificacion.put('cuerpo', 'Se desasignaron ordenes de su gestión');
				v_notificacion.put('estado', 'desasignada');
				v_notificacion.put('tipo', 'gestion_ordenes_scr');
				v_notificacion.put('fecha_envio', to_char(systimestamp, 'DD/MM/YYYY HH:MI:SS:FF PM'));

				v_json_array_notificacion.append(v_notificacion);

			exception
				when others then 
					dbms_output.put_line('Error al armar la notificacion OP360: '|| sqlerrm);
					null;
			end;

            sb_actualizar_temp(v_temp(i).numero_orden, '0', 'Ok');
        end loop;
        
        -- se mandan las notificaciones en segundo plano
        if v_json_array_notificacion.get_size > 0 then
            aire.pkg_g_generales.prc_enviar_notificaciones_push_segundo_plano(
                e_notificaciones => v_json_array_notificacion.to_clob, 
                s_respuesta	     => v_respuesta
            );
        end if;

        insert into aire.gnl_archivos_instancia (
                id_archivo,
                nombre_archivo,
                numero_registros_archivo,
                numero_registros_procesados,
                numero_errores,
                fecha_inicio_cargue,
                fecha_fin_cargue,
                duracion,
                id_usuario_registro,
                fecha_registro,
                id_estado_intancia,
                observaciones,
                id_soporte
        ) values(
            v_id_archivo,
            v_nombre_archivo,
            v_contador_exito + v_contador_error,
            v_contador_exito,
            v_contador_error,
            v_fecha_inicio,
            localtimestamp,
            localtimestamp - v_fecha_inicio,
            v_id_usuario_registra,
            localtimestamp,
            163, --Finalizado 
            'Archivo procesado con exito',
            v_id_soporte
        ) returning id_archivo_instancia into v_id_archivo_instancia;

        -- registramos la instancia detalle
        insert into aire.gnl_archivos_instancia_detalle(
              id_archivo_instancia
            , numero_fila
            , estado
            , observaciones
        ) select v_id_archivo_instancia id_archivo_instancia
               , rownum numero_fila
               , case when con_errores = 1 then 'ERROR' else 'OK' end estado
               , desc_validacion observaciones
            from aire.ord_ordenes_temporal_desasignacion_tecnico  
           where id_soporte       = v_id_soporte 
             and usuario_registra = v_id_usuario_registra;
        
        -- eliminamos la tabla temporal
		delete aire.ord_ordenes_temporal_desasignacion_tecnico
         where id_soporte       = v_id_soporte 
           and usuario_registra = v_id_usuario_registra;
        
        sb_escribir_respuesta(0, 'Archivo procesado');
    exception
        when others then
            sb_escribir_respuesta(1, 'Error al procesar ordenes:'|| sqlerrm);
    end prc_desasignar_ordenes_masivo_tecnico;
end pkg_g_carlos_vargas_test7;